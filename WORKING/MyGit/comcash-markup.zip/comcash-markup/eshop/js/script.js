$(function(){
//  show hide responsive menu
    $('#mobile_menu').click(function(){
        if(window.scrollY!=false){
            $('body').scrollTop(0);
            $(this).find('a').toggleClass('active');
            $('#mobile_navi').toggle();
        }
        else{
            $(this).find('a').toggleClass('active');
            $('#mobile_navi').toggle();
        }
    });
    $('#mobile_search').click(function(){
        if(window.scrollY!=false){
            $('body').scrollTop(0);
            $(this).parent().find(".active").removeClass('.active');
            $(this).find('a').toggleClass('active');
            $('#mobile_search_block').toggle();
        }
        else{
            $(this).find('a').toggleClass('active');
            $('#mobile_search_block').toggle();
        }
    });




    $('ul>.children').append('<div></div>');
    $('.children>div').click(function(){
        $(this).prev().stop(false,true).slideToggle();
        $(this).parent().toggleClass('active');
        if($(this).attr('class')=="active"){
            $(this).removeClass("active");
        }
        else{
            $(this).addClass("active");
        }
    });
    $('.category_header_catalog>div,' +
        '.category_header_filters>div:first-child').click(function(){
           $(this)
               .find('div')
               .toggleClass('active')
               .parent()
               .next()
               .stop(false,true)
               .slideToggle();
    });

    jQuery.fn.catalogCheckBox = function(){

        this.click(function(){
            $(this).toggleClass('active');
            if($(this).attr('class') != 'filter_check active'){
                $(this).parent().removeClass('checked');
            }
            else{
                $(this).parent().addClass('checked');
            }
        });

    };

    jQuery.fn.customCheckBox = function(){
        this.hide();
        this.parent().append('<div class="custom_checkbox"></div>');
        $('.custom_checkbox').click(function(){
            $(this).toggleClass('checked');
        });
    };



    $('input[type="checkbox"]').customCheckBox();
    $('div.filter_check').catalogCheckBox();

    var searchInput = $('.search_container input');

    searchInput.focus(function(){
        $(this).animate({"width":'70%'},400).css("background-color","#fff");
    });
    searchInput.blur(function(){
        $(this).animate({"width":'50%'},400).css("background-color","#dbdbdb");
    });

});