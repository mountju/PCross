$(function(){
    var defineAcccordeon = $('.home_accordeon');

    $.fn.accordeon = function(){
        var clickableRegion = this.find('.acc_header');

        clickableRegion.on("click",function(){
            var slideBlock = $(this).next(),
                context = $(this),
                slideOff = function(){
                    context.removeClass('active');
                    slideBlock.stop(true,false).slideUp('slow');
                },
                slideOn = function(){
                    context.addClass('active');
                    slideBlock.stop(true,true).slideDown('slow');
                };

            context.hasClass('active')?slideOff():slideOn();

        });
    };

    defineAcccordeon.accordeon();


});